<?php
// TEMPORARY ERROR REPORTING (To ensure no more blank 500 errors)
ini_set('display_errors', 0); // Turned off for production speed
error_reporting(E_ALL);

require_once '../includes/auth.php';
requireAdminOrReport(); 

$pdo = getConnection();
$today = date('Y-m-d');
$current_user_name = $_SESSION['name'] ?? 'Reporter'; 

// =========================================================================
// 1. REDIS CACHING SYSTEM SETUP
// =========================================================================
$redis = null;
try {
    if (class_exists('Redis')) {
        $redis = new Redis();
        $redis->connect('127.0.0.1', 56617); 
        $redis->auth('YOUR_PASSWORD'); 
    }
} catch (Exception $e) {
    $redis = null; 
}

$cache_key = "report_dashboard_stats_" . $today;
$stats = [];

// =========================================================================
// 2. ULTRA-FAST DATA FETCHING (COMBINED QUERIES)
// =========================================================================
if ($redis && $redis->exists($cache_key)) {
    $stats = json_decode($redis->get($cache_key), true);
} else {
    try {
        // QUERY 1: Global Master Counts (4 lookups in 1 query)
        $stmt = $pdo->query("SELECT 
            (SELECT COUNT(*) FROM users WHERE role = 'agent') as total_agents,
            (SELECT COUNT(*) FROM stores) as total_stores,
            (SELECT COUNT(*) FROM regions) as total_regions,
            (SELECT COUNT(*) FROM bank_submissions) as total_submissions
        ");
        $stats = array_merge($stats, $stmt->fetch(PDO::FETCH_ASSOC));

        // QUERY 2: Global Assignment Metrics (2 lookups in 1 query)
        $stmt = $pdo->query("SELECT 
            COUNT(*) as total_assignments,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_assignments
        FROM daily_assignments");
        $stats = array_merge($stats, $stmt->fetch(PDO::FETCH_ASSOC));
        
        $stats['completion_percentage'] = $stats['total_assignments'] > 0 ? round(($stats['completed_assignments'] / $stats['total_assignments']) * 100, 1) : 0;

        // QUERY 3: Today's Agent & Store Metrics (3 lookups in 1 query)
        $stmt = $pdo->prepare("SELECT 
            COUNT(DISTINCT agent_id) as agents_assigned,
            COUNT(*) as total_stores_today,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_stores
        FROM daily_assignments WHERE DATE(date_assigned) = ?");
        $stmt->execute([$today]);
        $temp_stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Ensure nulls from SUM are converted to 0
        $stats['agents_assigned'] = $temp_stats['agents_assigned'] ?: 0;
        $stats['total_stores_today'] = $temp_stats['total_stores_today'] ?: 0;
        $stats['completed_stores'] = $temp_stats['completed_stores'] ?: 0;
        $stats['completion_rate_today'] = $stats['total_stores_today'] > 0 ? round(($stats['completed_stores'] / $stats['total_stores_today']) * 100, 1) : 0;

        // QUERY 4: Today's Mall, Cash & Bank Metrics
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT s.mall) as total_malls, COUNT(DISTINCT CASE WHEN da.status = 'completed' THEN s.mall END) as completed_malls FROM daily_assignments da JOIN stores s ON da.store_id = s.id WHERE DATE(da.date_assigned) = ?");
        $stmt->execute([$today]);
        $stats = array_merge($stats, $stmt->fetch(PDO::FETCH_ASSOC));

        $stmt = $pdo->prepare("SELECT COUNT(*) as total_submissions_today FROM bank_submissions WHERE DATE(created_at) = ?");
        $stmt->execute([$today]);
        $stats['total_submissions_today'] = $stmt->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("SELECT SUM(cash_amount) as total_collected FROM shop_visits WHERE DATE(visit_date) = ?");
        $stmt->execute([$today]);
        $stats['total_collected'] = $stmt->fetchColumn() ?: 0;

        // Save to Redis for 5 minutes
        if ($redis) {
            $redis->setex($cache_key, 300, json_encode($stats));
        }
    } catch (PDOException $e) {
        die("<div style='padding:20px; background:#ffdddd; color:#aa0000; font-family:sans-serif;'>Database Query Error: " . $e->getMessage() . "</div>");
    }
}

extract($stats);

// Fetch active agents for the Export Dropdowns
try {
    $agent_stmt = $pdo->query("SELECT id, name FROM users WHERE role = 'agent' ORDER BY name ASC");
    $active_agents = $agent_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Failed to fetch agents list: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Command Center - Apparels Collection</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200');

        :root {
            --primary-bg: linear-gradient(135deg, #09090e, #1a1a2e, #16213e);
            --card-bg: rgba(23, 25, 49, 0.4);
            --card-border: rgba(255, 255, 255, 0.08);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --accent-indigo: #6366f1;
            --accent-emerald: #10b981;
            --accent-blue: #3b82f6;
            --accent-amber: #f59e0b;
            --danger: #ef4444;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: var(--primary-bg); 
            background-attachment: fixed;
            color: var(--text-primary); 
            line-height: 1.6; 
            min-height: 100vh; 
            overflow-x: hidden; 
        }

        /* Glassmorphism Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.4); }

        /* Full Width Navbar */
        .top-navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            background: rgba(15, 12, 41, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--card-border);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-brand { display: flex; align-items: center; gap: 15px; }
        .nav-brand img { width: 50px; height: auto; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3)); }
        .nav-title { font-size: 20px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; background: linear-gradient(to right, #fff, #94a3b8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        
        .nav-controls { display: flex; align-items: center; gap: 30px; }
        .time-display { text-align: right; display: flex; align-items: center; gap: 10px; }
        .time-display h2 { font-size: 22px; font-weight: 500; letter-spacing: 1px; margin: 0; }
        .time-display span { color: var(--accent-indigo); font-weight: 600; font-size: 13px; text-transform: uppercase; }

        .logout-btn { 
            display: flex; align-items: center; gap: 8px; padding: 10px 20px; 
            background: rgba(239, 68, 68, 0.1); color: var(--danger); 
            border-radius: 8px; text-decoration: none; font-weight: 600; 
            transition: var(--transition); border: 1px solid rgba(239, 68, 68, 0.2);
        }
        .logout-btn:hover { background: var(--danger); color: white; box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }

        /* Main Container */
        .dashboard-container { max-width: 1600px; margin: 0 auto; padding: 40px; }

        .welcome-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; }
        .welcome-row h1 { font-size: 32px; font-weight: 800; margin-bottom: 5px;}
        
        .live-indicator { display: inline-block; width: 8px; height: 8px; background: var(--accent-emerald); border-radius: 50%; box-shadow: 0 0 0 rgba(16, 185, 129, 0.4); animation: pulse 2s infinite; margin-right: 8px;}
        @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); } 70% { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); } 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); } }

        /* Grids */
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .export-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 25px; margin-bottom: 40px; }

        /* Premium Cards */
        .card { 
            background: var(--card-bg); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); 
            border: 1px solid var(--card-border); border-radius: 16px; padding: 25px; 
            transition: var(--transition); position: relative; overflow: hidden;
        }
        .card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 3px; background: rgba(255,255,255,0.1); }
        .card:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(0,0,0,0.4); border-color: rgba(255,255,255,0.15); }

        .card.accent-emerald::before { background: var(--accent-emerald); }
        .card.accent-indigo::before { background: var(--accent-indigo); }
        .card.accent-amber::before { background: var(--accent-amber); }
        .card.accent-blue::before { background: var(--accent-blue); }

        .kpi-value { font-size: 38px; font-weight: 800; margin: 10px 0 5px; line-height: 1; }
        .kpi-label { font-size: 14px; color: var(--text-secondary); font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
        .icon-wrapper { position: absolute; top: 20px; right: 20px; opacity: 0.8; }
        
        .progress-container { width: 100%; background: rgba(0,0,0,0.3); height: 6px; border-radius: 10px; margin-top: 15px; overflow: hidden; }
        .progress-bar { height: 100%; border-radius: 10px; transition: width 1.5s ease-out; }

        /* Export Forms */
        .export-header { display: flex; align-items: center; gap: 15px; margin-bottom: 20px; }
        .export-header .material-symbols-outlined { font-size: 32px; padding: 12px; border-radius: 12px; background: rgba(0,0,0,0.2); }
        .export-title { font-size: 20px; font-weight: 700; color: #fff; }
        .export-desc { font-size: 13px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 25px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.7); margin-bottom: 6px; text-transform: uppercase;}
        .form-control { 
            width: 100%; padding: 12px 15px; background: rgba(0,0,0,0.25); border: 1px solid rgba(255,255,255,0.1); 
            border-radius: 8px; color: white; font-family: inherit; font-size: 14px; transition: var(--transition);
        }
        .form-control:focus { outline: none; border-color: var(--accent-indigo); background: rgba(0,0,0,0.4); }
        .form-control option { background: #171931; color: white; }
        
        .btn-export { 
            width: 100%; padding: 14px; border-radius: 8px; font-weight: 700; font-size: 14px; 
            display: flex; align-items: center; justify-content: center; gap: 8px; 
            cursor: pointer; border: none; transition: var(--transition); margin-top: 10px;
            text-transform: uppercase; letter-spacing: 1px;
        }
        .btn-emerald { background: var(--accent-emerald); color: #fff; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2); }
        .btn-emerald:hover { background: #0ea5e9; transform: translateY(-2px); }
        .btn-indigo { background: var(--accent-indigo); color: #fff; box-shadow: 0 4px 15px rgba(99, 102, 241, 0.2); }
        .btn-indigo:hover { background: #4f46e5; transform: translateY(-2px); }
        .btn-blue { background: var(--accent-blue); color: #fff; box-shadow: 0 4px 15px rgba(59, 130, 246, 0.2); }
        .btn-blue:hover { background: #2563eb; transform: translateY(-2px); }
        .btn-white { background: #fff; color: #000; }
        .btn-white:hover { background: #e2e8f0; transform: translateY(-2px); }

        .section-title { font-size: 20px; font-weight: 700; margin: 40px 0 20px; color: #fff; display: flex; align-items: center; gap: 10px; }
        .section-title::before { content: ''; display: block; width: 4px; height: 20px; background: var(--text-primary); border-radius: 4px; }

        @media (max-width: 992px) {
            .top-navbar { flex-direction: column; gap: 15px; padding: 15px 20px; }
            .nav-controls { width: 100%; justify-content: space-between; }
            .dashboard-container { padding: 20px; }
            .welcome-row { flex-direction: column; align-items: flex-start; gap: 10px; }
        }
    </style>
</head>
<body>

    <nav class="top-navbar">
        <div class="nav-brand">
            <img src="../images/logo.png" alt="Logo">
            <div class="nav-title">Apparel Reporting</div>
        </div>
        
        <div class="nav-controls">
            <div class="time-display">
                <span id="date-display">--</span>
                <h2 id="clock">00:00:00</h2>
            </div>
            <a href="../logout.php" class="logout-btn">
                <span class="material-symbols-outlined">logout</span> Exit
            </a>
        </div>
    </nav>
    
    <div class="dashboard-container">
        
        <div class="welcome-row">
            <div>
                <h1>Command Center</h1>
                <p style="color: var(--text-secondary); margin-top: 5px;">
                    <span class="live-indicator"></span> 
                    Live Connection Active &bull; Logged in as <?php echo htmlspecialchars($current_user_name); ?>
                </p>
            </div>
        </div>

        <div class="section-title">Today's Live Pulse</div>
        <div class="metrics-grid">
            <div class="card accent-emerald">
                <div class="icon-wrapper" style="color: var(--accent-emerald);">
                    <span class="material-symbols-outlined" style="font-size: 32px;">payments</span>
                </div>
                <div class="kpi-label">Physical Cash Collected</div>
                <div class="kpi-value" style="color: var(--accent-emerald);">SAR <?php echo number_format($total_collected, 2); ?></div>
                <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">From <?php echo $total_submissions_today; ?> Bank Submissions</div>
            </div>

            <div class="card accent-indigo">
                <div class="icon-wrapper" style="color: var(--accent-indigo);">
                    <span class="material-symbols-outlined" style="font-size: 32px;">storefront</span>
                </div>
                <div class="kpi-label">Store Coverage (Today)</div>
                <div class="kpi-value"><?php echo $completed_stores; ?> <span style="font-size: 18px; color: var(--text-secondary);">/ <?php echo $total_stores_today; ?></span></div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: <?php echo $completion_rate_today; ?>%; background: var(--accent-indigo);"></div>
                </div>
            </div>

            <div class="card accent-amber">
                <div class="icon-wrapper" style="color: var(--accent-amber);">
                    <span class="material-symbols-outlined" style="font-size: 32px;">groups</span>
                </div>
                <div class="kpi-label">Active Agents Deployed</div>
                <div class="kpi-value"><?php echo $agents_assigned; ?> <span style="font-size: 18px; color: var(--text-secondary);">/ <?php echo $total_agents; ?></span></div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: <?php echo $total_agents > 0 ? ($agents_assigned/$total_agents)*100 : 0; ?>%; background: var(--accent-amber);"></div>
                </div>
            </div>
            
            <div class="card accent-blue">
                <div class="icon-wrapper" style="color: var(--accent-blue);">
                    <span class="material-symbols-outlined" style="font-size: 32px;">domain</span>
                </div>
                <div class="kpi-label">Malls Covered (Today)</div>
                <div class="kpi-value"><?php echo $completed_malls; ?> <span style="font-size: 18px; color: var(--text-secondary);">/ <?php echo $total_malls; ?></span></div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: <?php echo $total_malls > 0 ? ($completed_malls/$total_malls)*100 : 0; ?>%; background: var(--accent-blue);"></div>
                </div>
            </div>
        </div>

        <div class="section-title">Global Database Metrics</div>
        <div class="metrics-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
            <div class="card" style="padding: 15px 25px;">
                <div class="kpi-label">Total Stores</div>
                <div class="kpi-value" style="font-size: 28px;"><?php echo $total_stores; ?></div>
            </div>
            <div class="card" style="padding: 15px 25px;">
                <div class="kpi-label">Total Regions</div>
                <div class="kpi-value" style="font-size: 28px;"><?php echo $total_regions; ?></div>
            </div>
            <div class="card" style="padding: 15px 25px;">
                <div class="kpi-label">Total Submissions</div>
                <div class="kpi-value" style="font-size: 28px;"><?php echo $total_submissions; ?></div>
            </div>
            <div class="card" style="padding: 15px 25px;">
                <div class="kpi-label">Historical Completion</div>
                <div class="kpi-value" style="font-size: 28px; color: var(--accent-emerald);"><?php echo $completion_percentage; ?>%</div>
            </div>
        </div>

        <div class="section-title">Data Export Engine</div>
        <div class="export-grid">
            
            <div class="card">
                <div class="export-header">
                    <span class="material-symbols-outlined" style="color: var(--accent-emerald);">account_balance_wallet</span>
                    <div class="export-title">Cash Collections</div>
                </div>
                <p class="export-desc">Generate a complete ledger of all physical cash reported by agents during shop visits.</p>
                
                <form action="api/export_daily.php" method="GET" target="_blank">
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label>Start Date</label>
                            <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-01'); ?>" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label>End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo $today; ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-export btn-emerald">
                        <span class="material-symbols-outlined">download</span> Export Ledger
                    </button>
                </form>
            </div>

            <div class="card">
                <div class="export-header">
                    <span class="material-symbols-outlined" style="color: var(--accent-indigo);">query_stats</span>
                    <div class="export-title">Agent Analytics</div>
                </div>
                <p class="export-desc">Isolate and export operational performance data for individual agents or the whole team.</p>
                
                <form action="api/export_weekly.php" method="GET" target="_blank">
                    <div class="form-group">
                        <label>Select Target</label>
                        <select name="agent_id" class="form-control" required>
                            <option value="all">-- Entire Team --</option>
                            <?php foreach($active_agents as $agent): ?>
                                <option value="<?php echo $agent['id']; ?>"><?php echo htmlspecialchars($agent['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label>Start Date</label>
                            <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('-7 days')); ?>" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label>End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo $today; ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-export btn-indigo">
                        <span class="material-symbols-outlined">analytics</span> Run Analytics
                    </button>
                </form>
            </div>

            <div class="card">
                <div class="export-header">
                    <span class="material-symbols-outlined" style="color: var(--accent-blue);">account_balance</span>
                    <div class="export-title">Bank Deposits</div>
                </div>
                <p class="export-desc">Audit trail for physical bank deposit slips, linking agents to their approved or pending drops.</p>
                
                <form action="api/export_bank_deposits.php" method="GET" target="_blank">
                    <div class="form-group">
                        <label>Approval Status</label>
                        <select name="status" class="form-control" required>
                            <option value="all">All Records</option>
                            <option value="approved">Approved Deposits Only</option>
                            <option value="pending">Pending Verification Only</option>
                        </select>
                    </div>
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label>Start Date</label>
                            <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-01'); ?>" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label>End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo $today; ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-export btn-blue">
                        <span class="material-symbols-outlined">receipt_long</span> Extract Audit
                    </button>
                </form>
            </div>

            <div class="card" style="display: flex; flex-direction: column; justify-content: center;">
                <div class="export-header" style="margin-bottom: 10px;">
                    <span class="material-symbols-outlined" style="color: #fff; background: rgba(255,255,255,0.1);">database</span>
                    <div class="export-title">Master Store Coverage</div>
                </div>
                <p class="export-desc">Generate a master list of all stores and their current assignment status across all regions.</p>
                
                <form action="api/export_collections.php" method="GET" target="_blank">
                    <div class="form-group">
                        <label>Assignment Status</label>
                        <select name="focus" class="form-control" required>
                            <option value="all">Complete Database</option>
                            <option value="completed">Completed Status Only</option>
                            <option value="pending">Pending Status Only</option>
                        </select>
                    </div>
                    <input type="hidden" name="format" value="csv">
                    <button type="submit" class="btn-export btn-white">
                        <span class="material-symbols-outlined" style="color: #000;">table_view</span> Extract Master File
                    </button>
                </form>
            </div>

        </div>
    </div>

    <script>
        function updateClock() {
            const now = new Date();
            let hours = now.getHours();
            let minutes = now.getMinutes();
            let seconds = now.getSeconds();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            
            hours = hours % 12;
            hours = hours ? hours : 12; 
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            
            document.getElementById('clock').textContent = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
            
            const options = { weekday: 'short', month: 'short', day: 'numeric' };
            document.getElementById('date-display').textContent = now.toLocaleDateString('en-US', options);
        }
        
        setInterval(updateClock, 1000);
        updateClock(); 
    </script>
</body>
</html>