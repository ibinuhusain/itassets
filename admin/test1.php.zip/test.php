<?php
ini_set('display_errors', 0); 
error_reporting(E_ALL);

require_once '../includes/auth.php';
requireAdminOrReport(); 

$pdo = getConnection();
$today = date('Y-m-d');
$current_user_name = $_SESSION['name'] ?? 'Operations Manager'; 

$message = '';
$error = '';

// =========================================================================
// 1. HANDLE FORM SUBMISSIONS (CREATE AGENT & ASSIGNMENT)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_agent'])) {
        $username = trim($_POST['username']);
        $name = trim($_POST['name']);
        $phone = trim($_POST['phone']);
        $password = trim($_POST['password']);
        
        if (!empty($username) && !empty($name) && !empty($password)) {
            try {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password, name, phone, role) VALUES (?, ?, ?, ?, 'agent')");
                $stmt->execute([$username, $hashed_password, $name, $phone]);
                $message = 'Agent profile created successfully!';
            } catch (PDOException $e) {
                $error = 'Error creating agent. Username might already exist.';
            }
        } else {
            $error = 'Please fill all required agent fields.';
        }
    } 
    elseif (isset($_POST['create_assignment'])) {
        $agent_id = $_POST['agent_id'];
        $store_id = $_POST['store_id'];
        $date = $_POST['assignment_date'];
        
        if (!empty($agent_id) && !empty($store_id) && !empty($date)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO daily_assignments (agent_id, store_id, date_assigned, status) VALUES (?, ?, ?, 'pending')");
                $stmt->execute([$agent_id, $store_id, $date]);
                $message = 'Store assignment dispatched successfully!';
            } catch (PDOException $e) {
                $error = 'Error creating assignment.';
            }
        }
    }
}

// =========================================================================
// 2. ULTRA-FAST DATA FETCHING (METRICS & CHARTS)
// =========================================================================
$stats = [];
try {
    // Top-Level Metrics
    $stmt = $pdo->query("SELECT 
        (SELECT COUNT(*) FROM users WHERE role = 'agent') as total_agents,
        (SELECT COUNT(*) FROM stores) as total_stores,
        (SELECT COUNT(*) FROM daily_assignments) as total_assignments,
        (SELECT SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) FROM daily_assignments) as completed_assignments,
        (SELECT COUNT(*) FROM daily_assignments WHERE DATE(date_assigned) = '$today') as today_assignments,
        (SELECT SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) FROM daily_assignments WHERE DATE(date_assigned) = '$today') as today_completed
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Safety checks for nulls
    $stats['today_assignments'] = $stats['today_assignments'] ?: 0;
    $stats['today_completed'] = $stats['today_completed'] ?: 0;
    $stats['completed_assignments'] = $stats['completed_assignments'] ?: 0;
    $stats['pending_assignments'] = $stats['total_assignments'] - $stats['completed_assignments'];

    // CHART DATA: Top 5 Agents by Completed Assignments
    $stmt = $pdo->query("SELECT u.name, COUNT(da.id) as completed_count FROM daily_assignments da JOIN users u ON da.agent_id = u.id WHERE da.status = 'completed' GROUP BY u.id ORDER BY completed_count DESC LIMIT 5");
    $top_agents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // CHART DATA: Top 5 Malls by Store Count
    $stmt = $pdo->query("SELECT mall, COUNT(id) as store_count FROM stores WHERE mall IS NOT NULL AND mall != '' GROUP BY mall ORDER BY store_count DESC LIMIT 5");
    $top_malls = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // CHART DATA: Assignments by Region
    $stmt = $pdo->query("SELECT r.name, COUNT(da.id) as assign_count FROM daily_assignments da JOIN stores s ON da.store_id = s.id JOIN regions r ON s.region_id = r.id GROUP BY r.id ORDER BY assign_count DESC LIMIT 5");
    $top_regions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // FETCH FORMS DATA: Active Agents & Stores
    $agent_stmt = $pdo->query("SELECT id, name FROM users WHERE role = 'agent' ORDER BY name ASC");
    $active_agents = $agent_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $store_stmt = $pdo->query("SELECT id, name, mall FROM stores ORDER BY name ASC");
    $all_stores = $store_stmt->fetchAll(PDO::FETCH_ASSOC);

    // RECENT ASSIGNMENTS TABLE DATA
    $recent_stmt = $pdo->query("SELECT da.id, da.date_assigned, u.name as agent, s.name as store, da.status FROM daily_assignments da JOIN users u ON da.agent_id = u.id JOIN stores s ON da.store_id = s.id ORDER BY da.id DESC LIMIT 6");
    $recent_assignments = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("<div style='padding:20px; background:#ffdddd; color:#aa0000;'>Database Error: " . $e->getMessage() . "</div>");
}

extract($stats);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operations Command - Apparels Collection</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200');

        :root {
            --primary-bg: linear-gradient(135deg, #09090e, #1a1a2e, #16213e);
            --card-bg: rgba(23, 25, 49, 0.5);
            --card-border: rgba(255, 255, 255, 0.08);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --accent-indigo: #6366f1;
            --accent-emerald: #10b981;
            --accent-amber: #f59e0b;
            --danger: #ef4444;
            --transition: all 0.3s ease;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: var(--primary-bg); background-attachment: fixed; color: var(--text-primary); line-height: 1.6; min-height: 100vh; }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 4px; }

        /* Navbar */
        .top-navbar { display: flex; justify-content: space-between; align-items: center; padding: 15px 40px; background: rgba(15, 12, 41, 0.8); backdrop-filter: blur(20px); border-bottom: 1px solid var(--card-border); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 15px; }
        .nav-brand img { width: 40px; }
        .nav-title { font-size: 20px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }
        .logout-btn { display: flex; align-items: center; gap: 8px; padding: 8px 16px; background: rgba(239, 68, 68, 0.1); color: var(--danger); border-radius: 8px; text-decoration: none; font-weight: 600; border: 1px solid rgba(239, 68, 68, 0.2); transition: var(--transition);}
        .logout-btn:hover { background: var(--danger); color: white; }

        .dashboard-container { max-width: 1600px; margin: 0 auto; padding: 30px 40px; }
        
        /* Alerts */
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 25px; font-weight: 500; }
        .alert-success { background: rgba(16, 185, 129, 0.2); border: 1px solid var(--accent-emerald); color: var(--accent-emerald); }
        .alert-danger { background: rgba(239, 68, 68, 0.2); border: 1px solid var(--danger); color: #fca5a5; }

        .section-title { font-size: 18px; font-weight: 700; margin: 30px 0 20px; color: #fff; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; gap: 10px; }
        .section-title::before { content: ''; display: block; width: 4px; height: 18px; background: var(--accent-indigo); border-radius: 4px; }

        /* Grids */
        .grid-3 { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        @media (max-width: 1200px) { .grid-2 { grid-template-columns: 1fr; } }

        /* Cards */
        .card { background: var(--card-bg); backdrop-filter: blur(12px); border: 1px solid var(--card-border); border-radius: 12px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        
        /* Mini KPIs */
        .kpi-row { display: flex; gap: 20px; margin-bottom: 20px; }
        .kpi-box { flex: 1; background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; text-align: center; border: 1px solid var(--card-border); }
        .kpi-num { font-size: 28px; font-weight: 800; color: var(--accent-indigo); line-height: 1; margin-bottom: 5px; }
        .kpi-lbl { font-size: 11px; text-transform: uppercase; color: var(--text-secondary); letter-spacing: 0.5px; }

        /* Forms */
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 12px; color: rgba(255,255,255,0.7); margin-bottom: 6px; text-transform: uppercase; }
        .form-control { width: 100%; padding: 10px 15px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: white; font-family: inherit; font-size: 14px; }
        .form-control:focus { outline: none; border-color: var(--accent-indigo); }
        .form-control option { background: #171931; color: white; }
        
        .btn { width: 100%; padding: 12px; border-radius: 8px; font-weight: 600; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; border: none; transition: var(--transition); text-transform: uppercase; }
        .btn-indigo { background: var(--accent-indigo); color: #fff; }
        .btn-indigo:hover { background: #4f46e5; }
        .btn-emerald { background: var(--accent-emerald); color: #fff; }
        .btn-emerald:hover { background: #0ea5e9; }

        /* Table */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid var(--card-border); }
        th { color: var(--text-secondary); font-weight: 600; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .badge-completed { background: rgba(16, 185, 129, 0.2); color: var(--accent-emerald); border: 1px solid rgba(16, 185, 129, 0.3); }
        .badge-pending { background: rgba(245, 158, 11, 0.2); color: var(--accent-amber); border: 1px solid rgba(245, 158, 11, 0.3); }
        
        /* Chart Container */
        .chart-container { position: relative; height: 250px; width: 100%; }
    </style>
</head>
<body>

    <nav class="top-navbar">
        <div class="nav-brand">
            <img src="../images/logo.png" alt="Logo">
            <div class="nav-title">Operations Command</div>
        </div>
        <a href="../logout.php" class="logout-btn">
            <span class="material-symbols-outlined">logout</span> Exit Session
        </a>
    </nav>
    
    <div class="dashboard-container">
        
        <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <div class="section-title">Performance Graphics</div>
        <div class="grid-3">
            <div class="card">
                <h3 style="font-size: 15px; margin-bottom: 15px; color: var(--text-secondary);">Top Agents (Completed Shops)</h3>
                <div class="chart-container"><canvas id="agentChart"></canvas></div>
            </div>
            
            <div class="card">
                <h3 style="font-size: 15px; margin-bottom: 15px; color: var(--text-secondary);">Top Regions by Assignment</h3>
                <div class="chart-container"><canvas id="regionChart"></canvas></div>
            </div>
            
            <div class="card">
                <h3 style="font-size: 15px; margin-bottom: 15px; color: var(--text-secondary);">Global Assignment Status</h3>
                <div class="chart-container"><canvas id="statusChart"></canvas></div>
            </div>
        </div>

        <div class="section-title">Operations Hub</div>
        <div class="grid-2">
            
            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <div class="card">
                    <h3 style="font-size: 16px; margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
                        <span class="material-symbols-outlined" style="color: var(--accent-emerald);">person_add</span> Create New Agent
                    </h3>
                    <form method="POST">
                        <input type="hidden" name="create_agent" value="1">
                        <div style="display: flex; gap: 15px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Full Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control" required>
                            </div>
                        </div>
                        <div style="display: flex; gap: 15px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Phone Number</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-emerald">Deploy Agent</button>
                    </form>
                </div>

                <div class="card">
                    <h3 style="font-size: 16px; margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">
                        <span class="material-symbols-outlined" style="color: var(--accent-indigo);">add_task</span> Dispatch Assignment
                    </h3>
                    <form method="POST">
                        <input type="hidden" name="create_assignment" value="1">
                        <div class="form-group">
                            <label>Select Agent</label>
                            <select name="agent_id" class="form-control" required>
                                <option value="">-- Choose Agent --</option>
                                <?php foreach($active_agents as $agent): ?>
                                    <option value="<?php echo $agent['id']; ?>"><?php echo htmlspecialchars($agent['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Select Store</label>
                            <select name="store_id" class="form-control" required>
                                <option value="">-- Choose Store --</option>
                                <?php foreach($all_stores as $store): ?>
                                    <option value="<?php echo $store['id']; ?>"><?php echo htmlspecialchars($store['name']) . ($store['mall'] ? ' (' . htmlspecialchars($store['mall']) . ')' : ''); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Assignment Date</label>
                            <input type="date" name="assignment_date" class="form-control" value="<?php echo $today; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-indigo">Dispatch to Field</button>
                    </form>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <div class="card">
                    <h3 style="font-size: 16px; margin-bottom: 15px;">Today's Pulse</h3>
                    <div class="kpi-row">
                        <div class="kpi-box">
                            <div class="kpi-num"><?php echo $today_assignments; ?></div>
                            <div class="kpi-lbl">Assigned Today</div>
                        </div>
                        <div class="kpi-box">
                            <div class="kpi-num" style="color: var(--accent-emerald);"><?php echo $today_completed; ?></div>
                            <div class="kpi-lbl">Completed Today</div>
                        </div>
                    </div>
                    
                    <h3 style="font-size: 16px; margin: 25px 0 10px; display: flex; justify-content: space-between;">
                        Recent Dispatches
                        <span style="font-size: 12px; font-weight: normal; color: var(--text-secondary);">Live Feed</span>
                    </h3>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Agent</th>
                                    <th>Store</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($recent_assignments)): ?>
                                    <tr><td colspan="4" style="text-align: center; color: var(--text-secondary);">No recent assignments found.</td></tr>
                                <?php else: ?>
                                    <?php foreach($recent_assignments as $ra): ?>
                                    <tr>
                                        <td><?php echo date('M j', strtotime($ra['date_assigned'])); ?></td>
                                        <td><?php echo htmlspecialchars($ra['agent']); ?></td>
                                        <td><?php echo htmlspecialchars(strlen($ra['store']) > 20 ? substr($ra['store'],0,20).'...' : $ra['store']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $ra['status']; ?>">
                                                <?php echo ucfirst($ra['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card" style="display: flex; flex-direction: column; justify-content: center; background: rgba(0,0,0,0.3);">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <span class="material-symbols-outlined" style="color: #fff; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">database</span>
                        <div>
                            <h4 style="font-size: 16px; margin-bottom: 2px;">Export Operations Data</h4>
                            <p style="font-size: 12px; color: var(--text-secondary);">Download full master CSV of all global assignments.</p>
                        </div>
                    </div>
                    <form action="api/export_collections.php" method="GET" target="_blank" style="display: flex; gap: 10px;">
                        <select name="focus" class="form-control" style="flex: 2;" required>
                            <option value="all">Entire Database</option>
                            <option value="completed">Completed Only</option>
                        </select>
                        <input type="hidden" name="format" value="csv">
                        <button type="submit" class="btn" style="flex: 1; background: #fff; color: #000;">Export</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <script>
        Chart.defaults.color = 'rgba(255, 255, 255, 0.6)';
        Chart.defaults.font.family = 'Inter';
        
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, beginAtZero: true },
                x: { grid: { display: false } }
            }
        };

        // 1. Top Agents Bar Chart
        const agentData = <?php echo json_encode($top_agents); ?>;
        new Chart(document.getElementById('agentChart'), {
            type: 'bar',
            data: {
                labels: agentData.map(d => d.name.split(' ')[0]), // Use first name for space
                datasets: [{
                    data: agentData.map(d => d.completed_count),
                    backgroundColor: 'rgba(16, 185, 129, 0.8)',
                    borderRadius: 4
                }]
            },
            options: commonOptions
        });

        // 2. Top Regions Doughnut Chart
        const regionData = <?php echo json_encode($top_regions); ?>;
        new Chart(document.getElementById('regionChart'), {
            type: 'doughnut',
            data: {
                labels: regionData.map(d => d.name),
                datasets: [{
                    data: regionData.map(d => d.assign_count),
                    backgroundColor: ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11 } } } },
                cutout: '70%'
            }
        });

        // 3. Status Pie Chart
        new Chart(document.getElementById('statusChart'), {
            type: 'pie',
            data: {
                labels: ['Completed', 'Pending'],
                datasets: [{
                    data: [<?php echo $completed_assignments; ?>, <?php echo $pending_assignments; ?>],
                    backgroundColor: ['rgba(16, 185, 129, 0.8)', 'rgba(245, 158, 11, 0.8)'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } }
            }
        });
    </script>
</body>
</html>