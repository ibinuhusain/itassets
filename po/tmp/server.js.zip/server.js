const express = require('express');
const router = express.Router();
const db = require('./db.js');

// Log to audit table helper
async function logAction(user, action, details) {
    await db.query('INSERT INTO audit_logs (username, action_type, details) VALUES (?, ?, ?)', [user, action, details]);
}

// GET all POs
router.get('/po/list', async (req, res) => {
    try {
        const [pos] = await db.query('SELECT * FROM purchase_orders ORDER BY created_at DESC');
        // Loop to attach line items to each PO
        for (let po of pos) {
            const [items] = await db.query('SELECT * FROM line_items WHERE po_id = ?', [po.id]);
            po.lineItems = items;
            po.dynamicAttributes = po.dynamic_attributes ? JSON.parse(po.dynamic_attributes) : {};
        }
        res.json(pos);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET Audit Logs
router.get('/audit-logs', async (req, res) => {
    try {
        const [logs] = await db.query('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100');
        res.json(logs);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST Create new PO
router.post('/po/create', async (req, res) => {
    const { id, poNumber, vendor, orderDate, department, paymentTerms, lineItems, dynamicAttributes, taxAmount, grandTotal, username } = req.body;
    
    try {
        // 1. Insert Core PO
        await db.query(
            `INSERT INTO purchase_orders (id, po_number, order_date, department, vendor, payment_terms, tax_amount, grand_total, dynamic_attributes, created_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, poNumber, orderDate, department, vendor, paymentTerms, taxAmount, grandTotal, JSON.stringify(dynamicAttributes), username]
        );

        // 2. Insert Line Items
        if (lineItems && lineItems.length > 0) {
            const itemQueries = lineItems.map(item => {
                return db.query('INSERT INTO line_items (po_id, sku, description, quantity, unit_price) VALUES (?, ?, ?, ?, ?)', 
                [id, item.sku, item.description, item.quantity, item.unitPrice]);
            });
            await Promise.all(itemQueries);
        }

        await logAction(username, 'CREATE', `Generated new PO: ${poNumber} for ${vendor}`);
        res.status(201).json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE PO
router.delete('/po/delete/:id', async (req, res) => {
    try {
        const { username, poNumber } = req.body; // Passed from frontend for logging
        await db.query('DELETE FROM purchase_orders WHERE id = ?', [req.params.id]);
        await logAction(username, 'DELETE', `Removed PO: ${poNumber}`);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;